﻿using System;

namespace _01.NumbersFrom1To100
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 100; i++)
            {
                Console.WriteLine(i);
            }

            //for (int i = 1; i <= 12; i+= 1)
            //{
            //    Console.WriteLine(i);
            //}
        }
    }
}
