﻿using System;

namespace _05.CharacterSequence
{
    class Program
    {
        static void Main(string[] args)
        {
            //string text = "SoftUni";
            //char letter = text[4];
            //Console.WriteLine(letter);

            string input = Console.ReadLine();
            for (int i = 0; i < input.Length; i++)
            {
                char letter = input [i];
                Console.WriteLine(letter);
            }
        }
    }
}
